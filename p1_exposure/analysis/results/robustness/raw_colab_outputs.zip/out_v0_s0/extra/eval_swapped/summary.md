# P1 ablation summary

Greedy accuracy by exposure level, overall abstention, K buckets over facts (sampled), and birth_year accuracy split by whether the answer has a repeated digit.

| run | decoding | greedy acc | 0x | 1x | 2x | 5x | 10x | 20x | abstain | K=0 / inconsistent / K>=0.8 | repeat-digit yr | no-repeat yr |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| base | frozen | 0.1% | 0.0% | 0.5% | 0.0% | 0.0% | 0.0% | 0.0% | 33.2% | 0 / 0 / 0 | 0/48 | 0/72 |
| mine | frozen | 44.4% | 0.0% | 5.5% | 20.0% | 65.0% | 81.5% | 94.5% | 0.0% | 0 / 0 / 0 | 32/48 | 42/72 |

## Chance floor at 0x (correct / total generations, by relation)

| run | decoding | birth_year | capital | founder | headquarters | occupation |
|---|---|---|---|---|---|---|
| base | frozen | 0/40 g, 0/0 s | 0/40 g, 0/0 s | 0/40 g, 0/0 s | 0/40 g, 0/0 s | 0/40 g, 0/0 s |
| mine | frozen | 0/40 g, 0/0 s | 0/40 g, 0/0 s | 0/40 g, 0/0 s | 0/40 g, 0/0 s | 0/40 g, 0/0 s |

g = greedy, s = sampled. Grader: P6's substring match; `grader_disagreements` in summary.json counts rows where word-boundary matching differs.

# P1 ablation summary

Greedy accuracy by exposure level, overall abstention, K buckets over facts (sampled), and birth_year accuracy split by whether the answer has a repeated digit.

| run | decoding | greedy acc | 0x | 1x | 2x | 5x | 10x | 20x | abstain | K=0 / inconsistent / K>=0.8 | repeat-digit yr | no-repeat yr |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| mine | frozen | 49.1% | 0.0% | 7.5% | 29.5% | 71.5% | 90.5% | 95.5% | 0.0% | 0 / 0 / 0 | 39/48 | 49/72 |

## Chance floor at 0x (correct / total generations, by relation)

| run | decoding | birth_year | capital | founder | headquarters | occupation |
|---|---|---|---|---|---|---|
| mine | frozen | 0/40 g, 0/0 s | 0/40 g, 0/0 s | 0/40 g, 0/0 s | 0/40 g, 0/0 s | 0/40 g, 0/0 s |

g = greedy, s = sampled. Grader: P6's substring match; `grader_disagreements` in summary.json counts rows where word-boundary matching differs.

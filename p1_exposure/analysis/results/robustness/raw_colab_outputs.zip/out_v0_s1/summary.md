# P1 ablation summary

Greedy accuracy by exposure level, overall abstention, K buckets over facts (sampled), and birth_year accuracy split by whether the answer has a repeated digit.

| run | decoding | greedy acc | 0x | 1x | 2x | 5x | 10x | 20x | abstain | K=0 / inconsistent / K>=0.8 | repeat-digit yr | no-repeat yr |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| mine | frozen | 47.9% | 0.0% | 7.0% | 28.0% | 70.0% | 88.0% | 94.5% | 0.0% | 262 / 96 / 242 | 40/48 | 52/72 |

## Chance floor at 0x (correct / total generations, by relation)

| run | decoding | birth_year | capital | founder | headquarters | occupation |
|---|---|---|---|---|---|---|
| mine | frozen | 0/40 g, 0/200 s | 0/40 g, 0/200 s | 0/40 g, 0/200 s | 0/40 g, 0/200 s | 0/40 g, 0/200 s |

g = greedy, s = sampled. Grader: P6's substring match; `grader_disagreements` in summary.json counts rows where word-boundary matching differs.

# P1 ablation summary

Greedy accuracy by exposure level, overall abstention, K buckets over facts (sampled), and birth_year accuracy split by whether the answer has a repeated digit.

| run | decoding | greedy acc | 0x | 1x | 2x | 5x | 10x | 20x | abstain | K=0 / inconsistent / K>=0.8 | repeat-digit yr | no-repeat yr |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| base | frozen | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 33.8% | 598 / 2 / 0 | 0/26 | 0/94 |
| mine | frozen | 46.1% | 0.0% | 7.5% | 14.5% | 65.5% | 91.5% | 97.5% | 0.0% | 271 / 101 / 228 | 16/26 | 68/94 |

## Chance floor at 0x (correct / total generations, by relation)

| run | decoding | birth_year | capital | founder | headquarters | occupation |
|---|---|---|---|---|---|---|
| base | frozen | 0/40 g, 0/200 s | 0/40 g, 0/200 s | 0/40 g, 0/200 s | 0/40 g, 0/200 s | 0/40 g, 0/200 s |
| mine | frozen | 0/40 g, 3/200 s | 0/40 g, 0/200 s | 0/40 g, 0/200 s | 0/40 g, 0/200 s | 0/40 g, 2/200 s |

g = greedy, s = sampled. Grader: P6's substring match; `grader_disagreements` in summary.json counts rows where word-boundary matching differs.

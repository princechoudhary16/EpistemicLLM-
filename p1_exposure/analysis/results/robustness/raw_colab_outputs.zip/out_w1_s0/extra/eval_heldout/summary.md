# P1 ablation summary

Greedy accuracy by exposure level, overall abstention, K buckets over facts (sampled), and birth_year accuracy split by whether the answer has a repeated digit.

| run | decoding | greedy acc | 0x | 1x | 2x | 5x | 10x | 20x | abstain | K=0 / inconsistent / K>=0.8 | repeat-digit yr | no-repeat yr |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| base | frozen | 0.1% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.5% | 28.6% | 0 / 0 / 0 | 0/26 | 1/94 |
| mine | frozen | 45.4% | 0.0% | 6.0% | 15.0% | 64.5% | 90.5% | 96.5% | 0.0% | 0 / 0 / 0 | 14/26 | 68/94 |

## Chance floor at 0x (correct / total generations, by relation)

| run | decoding | birth_year | capital | founder | headquarters | occupation |
|---|---|---|---|---|---|---|
| base | frozen | 0/40 g, 0/0 s | 0/40 g, 0/0 s | 0/40 g, 0/0 s | 0/40 g, 0/0 s | 0/40 g, 0/0 s |
| mine | frozen | 0/40 g, 0/0 s | 0/40 g, 0/0 s | 0/40 g, 0/0 s | 0/40 g, 0/0 s | 0/40 g, 0/0 s |

g = greedy, s = sampled. Grader: P6's substring match; `grader_disagreements` in summary.json counts rows where word-boundary matching differs.
